module.exports = Object.freeze({
  ID: "ID",
  UNKNOWN: "UNKNOWN",
})

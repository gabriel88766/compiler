const CONSTS = require("./consts")
const KEYWORDS = require("./keywords")
const SYMBOLS = require("./symbols")
const SPECIALS = require("./specials")

module.exports = {
  CONSTS,
  KEYWORDS,
  SYMBOLS,
  SPECIALS,
}

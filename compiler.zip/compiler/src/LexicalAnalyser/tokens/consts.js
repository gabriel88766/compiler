module.exports = Object.freeze({
  CHARACTER: "CHARACTER",
  NUMERAL: "NUMERAL",
  STRINGVAL: "STRINGVAL",
})
